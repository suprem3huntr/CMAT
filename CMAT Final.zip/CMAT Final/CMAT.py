import tkinter

import overpy
from geopy import Nominatim
import smopy
import matplotlib
import pandas as pd
import geopandas as gpd
import requests
import csv
from PIL import ImageTk,Image
from geopandas import GeoDataFrame
from time import sleep

def choropleth():
    
    fp="District_Boundary.shx"
    map_df=gpd.read_file(fp)
    map_df.head()
    
    url="https://www.karnataka.com/govt/district-wise-covid-19-cases/"
    html=requests.get(url).content
    df_list=pd.read_html(html)
    df=df_list[2]
    df.to_csv("temp.csv")

    with open("temp.csv","r")as a:
        text=''.join([i for i in a])
        text=text.replace("Bagalkote","Bagalkot")
        text=text.replace("Bengaluru Urban","Bengaluru (Urban)")
        text=text.replace("Bengaluru Rural","Bengaluru (Rural)")
        text=text.replace("Kalburgi","Kalaburagi")
        text=text.replace("Kolar","Kolara")
        with open("temp2.csv","w") as b:
            b.writelines(text)
    df=pd.read_csv("temp2.csv")

    df.head()
    merged = map_df.set_index('KGISDist_1').join(df.set_index('District'))

    merged.head()

    variable='Active Cases'




    vmin, vmax = 0,9000

    fig,ax = matplotlib.pyplot.subplots(1, figsize=(10,6))
   
    ax.axis('off')
    ax.set_title('Active Covid cases')
    sm = matplotlib.pyplot.cm.ScalarMappable(cmap='Reds', norm=matplotlib.pyplot.Normalize(vmin=vmin, vmax=vmax))
    sm._A = []
    cbar=fig.colorbar(sm)
    merged.plot(column=variable, cmap='Reds', linewidth=0.8, ax=ax, edgecolor='0.8')
    fig.savefig('map_export.png', dpi=300)
    img = Image.open('map_export.png')
    img = img.resize((500, 500), Image.ANTIALIAS)
    img = ImageTk.PhotoImage(img)
    panel = tkinter.Label(root, image = img)
    panel.image = img
    panel.grid(row = 3,column = 1,rowspan=3)

def geocode(loc):
    locator = Nominatim(user_agent="myGeocoder")
    location=locator.geocode(loc)
    print(location)
    return list([float(location.latitude),float(location.longitude)])
def getmap(coords):
    #print(coords)
    latmin=coords[0]-0.01
    latmax=coords[0]+0.01
    lonmin=coords[1]-0.01
    lonmax=coords[1]+0.01
    #print(latmin,latmax,lonmin,lonmax)
    map=smopy.Map((latmin,lonmin,latmax,lonmax),z=16)
    map.save_png("test.png")
    api=overpy.Overpass()
    result=api.query('node(around:1110 ,'+str(coords[0])+','+str(coords[1])+')["amenity"="hospital"];\nout;')
    ax = map.show_mpl(figsize=(8, 6))
    for i in result.nodes:
        
        x, y = map.to_pixels(float(i.lat),float(i.lon))
        
        ax.plot(x, y, 'or', ms=4, mew=2)
    
    matplotlib.pyplot.savefig('test.png')
    img = Image.open('test.png')
    img = img.resize((500, 500), Image.ANTIALIAS)
    img = ImageTk.PhotoImage(img)
    panel = tkinter.Label(root, image = img)
    panel.image = img
    panel.grid(row = 3,column = 2)

loadingscreen=tkinter.Tk()
loadingscreen.title("CMAT")
img = Image.open('loadingscreen.jpeg')
img = img.resize((500, 500), Image.ANTIALIAS)
img = ImageTk.PhotoImage(img)
panel = tkinter.Label(loadingscreen, image = img)
panel.image = img
panel.pack()
def main():
    loadingscreen.destroy()
    global root
    root=tkinter.Tk()
    root.title("CMAT")
    root.configure(background="#3db7c7")
    root.geometry=("550*300+ 300 +150")
    root.resizable(width=False,height=False)
    search=tkinter.Entry(root,width=100)
    confirm=tkinter.Button(root,text="confirm",command=lambda:getmap(geocode(search.get())))
    choropleth()
    search.grid(row=1,column=2)
    confirm.grid(row=2,column=2)
    root.mainloop()
loadingscreen.after(1000,main)



